"""
AI Chess Simulator - Complete Python Implementation
A fully functional chess game with AI opponent
"""

import copy
import random
from typing import List, Tuple, Optional

class ChessPiece:
    """Represents a chess piece"""
    def __init__(self, color: str, piece_type: str):
        self.color = color  # 'white' or 'black'
        self.piece_type = piece_type  # 'p', 'r', 'n', 'b', 'q', 'k'
        
    def __str__(self):
        pieces = {
            'white': {'k': '♔', 'q': '♕', 'r': '♖', 'b': '♗', 'n': '♘', 'p': '♙'},
            'black': {'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'}
        }
        return pieces[self.color][self.piece_type]
    
    def __repr__(self):
        return f"{self.color[0].upper()}{self.piece_type.upper()}"


class ChessBoard:
    """Manages the chess board and game state"""
    def __init__(self):
        self.board = self.initialize_board()
        self.current_player = 'white'
        self.move_history = []
        self.captured_pieces = {'white': [], 'black': []}
        
    def initialize_board(self) -> List[List[Optional[ChessPiece]]]:
        """Create initial chess board setup"""
        board = [[None for _ in range(8)] for _ in range(8)]
        
        # Black pieces
        board[0] = [
            ChessPiece('black', 'r'), ChessPiece('black', 'n'),
            ChessPiece('black', 'b'), ChessPiece('black', 'q'),
            ChessPiece('black', 'k'), ChessPiece('black', 'b'),
            ChessPiece('black', 'n'), ChessPiece('black', 'r')
        ]
        board[1] = [ChessPiece('black', 'p') for _ in range(8)]
        
        # White pieces
        board[6] = [ChessPiece('white', 'p') for _ in range(8)]
        board[7] = [
            ChessPiece('white', 'r'), ChessPiece('white', 'n'),
            ChessPiece('white', 'b'), ChessPiece('white', 'q'),
            ChessPiece('white', 'k'), ChessPiece('white', 'b'),
            ChessPiece('white', 'n'), ChessPiece('white', 'r')
        ]
        
        return board
    
    def display_board(self):
        """Display the chess board in terminal"""
        print("\n  " + "  ".join("abcdefgh"))
        print("  " + "─" * 24)
        for i, row in enumerate(self.board):
            print(f"{8-i}│", end=" ")
            for piece in row:
                if piece:
                    print(piece, end=" ")
                else:
                    print("·", end=" ")
            print(f"│{8-i}")
        print("  " + "─" * 24)
        print("  " + "  ".join("abcdefgh"))
        print()
    
    def is_valid_position(self, row: int, col: int) -> bool:
        """Check if position is within board bounds"""
        return 0 <= row < 8 and 0 <= col < 8
    
    def get_piece(self, row: int, col: int) -> Optional[ChessPiece]:
        """Get piece at position"""
        if self.is_valid_position(row, col):
            return self.board[row][col]
        return None
    
    def is_path_clear(self, from_row: int, from_col: int, 
                      to_row: int, to_col: int) -> bool:
        """Check if path between two squares is clear"""
        row_step = 0 if to_row == from_row else (1 if to_row > from_row else -1)
        col_step = 0 if to_col == from_col else (1 if to_col > from_col else -1)
        
        row, col = from_row + row_step, from_col + col_step
        
        while row != to_row or col != to_col:
            if self.board[row][col] is not None:
                return False
            row += row_step
            col += col_step
        
        return True
    
    def is_valid_move(self, from_row: int, from_col: int, 
                      to_row: int, to_col: int) -> bool:
        """Validate if a move is legal"""
        piece = self.get_piece(from_row, from_col)
        if not piece:
            return False
        
        target = self.get_piece(to_row, to_col)
        if target and target.color == piece.color:
            return False
        
        row_diff = to_row - from_row
        col_diff = to_col - from_col
        
        # Pawn movement
        if piece.piece_type == 'p':
            direction = -1 if piece.color == 'white' else 1
            start_row = 6 if piece.color == 'white' else 1
            
            # Forward move
            if col_diff == 0 and not target:
                if row_diff == direction:
                    return True
                if from_row == start_row and row_diff == 2 * direction:
                    return self.is_path_clear(from_row, from_col, to_row, to_col)
            
            # Capture
            if abs(col_diff) == 1 and row_diff == direction and target:
                return True
            
            return False
        
        # Rook movement
        elif piece.piece_type == 'r':
            if row_diff == 0 or col_diff == 0:
                return self.is_path_clear(from_row, from_col, to_row, to_col)
        
        # Knight movement
        elif piece.piece_type == 'n':
            return (abs(row_diff) == 2 and abs(col_diff) == 1) or \
                   (abs(row_diff) == 1 and abs(col_diff) == 2)
        
        # Bishop movement
        elif piece.piece_type == 'b':
            if abs(row_diff) == abs(col_diff):
                return self.is_path_clear(from_row, from_col, to_row, to_col)
        
        # Queen movement
        elif piece.piece_type == 'q':
            if row_diff == 0 or col_diff == 0 or abs(row_diff) == abs(col_diff):
                return self.is_path_clear(from_row, from_col, to_row, to_col)
        
        # King movement
        elif piece.piece_type == 'k':
            return abs(row_diff) <= 1 and abs(col_diff) <= 1
        
        return False
    
    def make_move(self, from_row: int, from_col: int, 
                  to_row: int, to_col: int) -> bool:
        """Execute a move on the board"""
        if not self.is_valid_move(from_row, from_col, to_row, to_col):
            return False
        
        piece = self.board[from_row][from_col]
        captured = self.board[to_row][to_col]
        
        if captured:
            self.captured_pieces[captured.color].append(captured)
        
        self.board[to_row][to_col] = piece
        self.board[from_row][from_col] = None
        
        # Record move
        from_pos = f"{chr(97 + from_col)}{8 - from_row}"
        to_pos = f"{chr(97 + to_col)}{8 - to_row}"
        self.move_history.append(f"{piece.color}: {from_pos} → {to_pos}")
        
        self.current_player = 'black' if self.current_player == 'white' else 'white'
        return True
    
    def get_all_valid_moves(self, color: str) -> List[Tuple]:
        """Get all valid moves for a color"""
        moves = []
        for row in range(8):
            for col in range(8):
                piece = self.board[row][col]
                if piece and piece.color == color:
                    for to_row in range(8):
                        for to_col in range(8):
                            if self.is_valid_move(row, col, to_row, to_col):
                                moves.append((row, col, to_row, to_col))
        return moves
    
    def evaluate_board(self) -> int:
        """Evaluate board position (positive favors black, negative favors white)"""
        piece_values = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100}
        score = 0
        
        for row in self.board:
            for piece in row:
                if piece:
                    value = piece_values[piece.piece_type]
                    score += value if piece.color == 'black' else -value
        
        return score
    
    def is_game_over(self) -> Tuple[bool, Optional[str]]:
        """Check if game is over and return winner"""
        white_has_king = any(
            piece and piece.piece_type == 'k' and piece.color == 'white'
            for row in self.board for piece in row
        )
        black_has_king = any(
            piece and piece.piece_type == 'k' and piece.color == 'black'
            for row in self.board for piece in row
        )
        
        if not white_has_king:
            return True, 'black'
        if not black_has_king:
            return True, 'white'
        
        # Check if current player has no valid moves
        if not self.get_all_valid_moves(self.current_player):
            winner = 'black' if self.current_player == 'white' else 'white'
            return True, winner
        
        return False, None


class ChessAI:
    """AI opponent for chess game"""
    def __init__(self, board: ChessBoard):
        self.board = board
    
    def get_best_move(self) -> Optional[Tuple]:
        """Calculate best move for AI (black)"""
        valid_moves = self.board.get_all_valid_moves('black')
        
        if not valid_moves:
            return None
        
        best_move = None
        best_score = float('-inf')
        
        for move in valid_moves:
            from_row, from_col, to_row, to_col = move
            
            # Simulate move
            test_board = copy.deepcopy(self.board)
            piece = test_board.board[from_row][from_col]
            captured = test_board.board[to_row][to_col]
            test_board.board[to_row][to_col] = piece
            test_board.board[from_row][from_col] = None
            
            score = test_board.evaluate_board()
            
            # Bonus for captures
            if captured:
                score += 10
            
            # Simple lookahead - check opponent's best response
            opponent_moves = test_board.get_all_valid_moves('white')
            if opponent_moves:
                # Sample a few opponent moves
                for opp_move in random.sample(opponent_moves, min(3, len(opponent_moves))):
                    o_from_row, o_from_col, o_to_row, o_to_col = opp_move
                    response_board = copy.deepcopy(test_board)
                    response_piece = response_board.board[o_from_row][o_from_col]
                    response_board.board[o_to_row][o_to_col] = response_piece
                    response_board.board[o_from_row][o_from_col] = None
                    response_score = response_board.evaluate_board()
                    score = min(score, response_score)
            
            if score > best_score:
                best_score = score
                best_move = move
        
        return best_move


class ChessGame:
    """Main game controller"""
    def __init__(self):
        self.board = ChessBoard()
        self.ai = ChessAI(self.board)
    
    def parse_position(self, pos: str) -> Optional[Tuple[int, int]]:
        """Convert chess notation (e.g., 'e2') to board coordinates"""
        if len(pos) != 2:
            return None
        
        col = ord(pos[0].lower()) - ord('a')
        row = 8 - int(pos[1])
        
        if self.board.is_valid_position(row, col):
            return row, col
        return None
    
    def display_game_info(self):
        """Display game information"""
        print("\n" + "="*50)
        print(f"Current Player: {self.board.current_player.upper()}")
        print(f"Moves Made: {len(self.board.move_history)}")
        print("="*50)
        
        print("\nCaptured Pieces:")
        print(f"White captured: {' '.join(str(p) for p in self.board.captured_pieces['white'])}")
        print(f"Black captured: {' '.join(str(p) for p in self.board.captured_pieces['black'])}")
        
        if self.board.move_history:
            print("\nLast 5 Moves:")
            for move in self.board.move_history[-5:]:
                print(f"  {move}")
    
    def player_turn(self):
        """Handle player's turn"""
        while True:
            try:
                move_input = input("\nYour move (e.g., 'e2 e4') or 'quit': ").strip().lower()
                
                if move_input == 'quit':
                    return False
                
                parts = move_input.split()
                if len(parts) != 2:
                    print("Invalid format! Use: e2 e4")
                    continue
                
                from_pos = self.parse_position(parts[0])
                to_pos = self.parse_position(parts[1])
                
                if not from_pos or not to_pos:
                    print("Invalid position! Use letters a-h and numbers 1-8")
                    continue
                
                from_row, from_col = from_pos
                to_row, to_col = to_pos
                
                piece = self.board.get_piece(from_row, from_col)
                if not piece or piece.color != 'white':
                    print("Please select your own white piece!")
                    continue
                
                if self.board.make_move(from_row, from_col, to_row, to_col):
                    return True
                else:
                    print("Invalid move! Try again.")
                    
            except Exception as e:
                print(f"Error: {e}. Please try again.")
    
    def ai_turn(self):
        """Handle AI's turn"""
        print("\n🤖 AI is thinking...")
        move = self.ai.get_best_move()
        
        if move:
            from_row, from_col, to_row, to_col = move
            self.board.make_move(from_row, from_col, to_row, to_col)
            from_pos = f"{chr(97 + from_col)}{8 - from_row}"
            to_pos = f"{chr(97 + to_col)}{8 - to_row}"
            print(f"AI moved: {from_pos} → {to_pos}")
            return True
        return False
    
    def play(self):
        """Main game loop"""
        print("\n" + "="*50)
        print("    🎮 AI CHESS SIMULATOR 🎮")
        print("="*50)
        print("\nWelcome! You are playing as WHITE (♙)")
        print("AI is playing as BLACK (♟)")
        print("\nCommands:")
        print("  - Move format: e2 e4 (from to)")
        print("  - Type 'quit' to exit")
        print("\nLet's begin!\n")
        
        while True:
            self.board.display_board()
            self.display_game_info()
            
            # Check game over
            is_over, winner = self.board.is_game_over()
            if is_over:
                print("\n" + "="*50)
                print(f"🏆 GAME OVER! {winner.upper()} WINS! 🏆")
                print("="*50)
                break
            
            # Player turn
            if self.board.current_player == 'white':
                if not self.player_turn():
                    print("\nThanks for playing!")
                    break
            
            # AI turn
            else:
                if not self.ai_turn():
                    print("\n🏆 YOU WIN! AI has no valid moves!")
                    break


def main():
    """Entry point for the chess game"""
    game = ChessGame()
    game.play()


if __name__ == "__main__":
    main()
