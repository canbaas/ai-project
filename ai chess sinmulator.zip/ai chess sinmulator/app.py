from flask import Flask, render_template_string

app = Flask(__name__)

HTML_TEMPLATE = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chess Game</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container { display: flex; gap: 30px; flex-wrap: wrap; justify-content: center; }
        .sidebar {
            background: #334155;
            border-radius: 12px;
            padding: 30px;
            width: 280px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .sidebar h1 { color: white; font-size: 32px; margin-bottom: 30px; }
        .turn-indicator { margin-bottom: 30px; }
        .turn-label { color: #94a3b8; font-size: 14px; margin-bottom: 10px; }
        .turn-display {
            background: linear-gradient(135deg, #e2e8f0 0%, #ffffff 100%);
            color: #1e293b;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }
        .turn-display.black {
            background: linear-gradient(135deg, #475569 0%, #1e293b 100%);
            color: white;
        }
        .game-over {
            background: linear-gradient(135deg, #10b981 0%, #059669 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 20px;
            display: none;
        }
        .game-over.show { display: block; }
        .captured-section { margin-bottom: 25px; }
        .captured-label { color: #94a3b8; font-size: 14px; margin-bottom: 8px; }
        .captured-pieces {
            background: #1e293b;
            border-radius: 8px;
            padding: 12px;
            min-height: 50px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        .captured-piece { font-size: 28px; }
        .new-game-btn {
            width: 100%;
            background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
        }
        .new-game-btn:hover { transform: translateY(-2px); }
        .board-container {
            background: #334155;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .chess-board { border: 4px solid #1e293b; border-radius: 4px; overflow: hidden; }
        .board-row { display: flex; }
        .square {
            width: 80px;
            height: 80px;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            position: relative;
        }
        .square.light { background: #f0d9b5; }
        .square.dark { background: #b58863; }
        .square.selected { box-shadow: inset 0 0 0 4px #3b82f6; }
        .square.valid-move:not(.has-piece) { background-color: #86efac !important; }
        .square.valid-move.has-piece { box-shadow: inset 0 0 0 4px #ef4444; }
        .piece {
            font-size: 60px;
            user-select: none;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .piece.white { color: white; filter: drop-shadow(0 2px 3px rgba(0,0,0,0.8)); }
        .piece.black { color: #1e293b; }
        .valid-move-indicator {
            width: 20px;
            height: 20px;
            background: #22c55e;
            border-radius: 50%;
            opacity: 0.7;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <h1>♔ Chess</h1>
            <div class="turn-indicator">
                <div class="turn-label">Current Turn</div>
                <div class="turn-display" id="turnDisplay">White</div>
            </div>
            <div class="game-over" id="gameOver">
                <div style="font-size: 20px; font-weight: bold;">Game Over!</div>
                <div id="winnerText"></div>
            </div>
            <div class="captured-section">
                <div class="captured-label">Captured by White</div>
                <div class="captured-pieces" id="capturedWhite"></div>
            </div>
            <div class="captured-section">
                <div class="captured-label">Captured by Black</div>
                <div class="captured-pieces" id="capturedBlack"></div>
            </div>
            <button class="new-game-btn" onclick="resetGame()">🔄 New Game</button>
        </div>
        <div class="board-container">
            <div class="chess-board" id="chessBoard"></div>
        </div>
    </div>
    <script>
        const PIECE_SYMBOLS = {
            king: '♚', queen: '♛', rook: '♜',
            bishop: '♝', knight: '♞', pawn: '♟'
        };
        let board = [];
        let selectedSquare = null;
        let validMoves = [];
        let currentPlayer = 'white';
        let gameOver = false;
        let winner = null;
        let capturedPieces = { white: [], black: [] };

        function initializeBoard() {
            board = Array(8).fill(null).map(() => Array(8).fill(null));
            for (let i = 0; i < 8; i++) {
                board[1][i] = { type: 'pawn', color: 'black' };
                board[6][i] = { type: 'pawn', color: 'white' };
            }
            board[0][0] = board[0][7] = { type: 'rook', color: 'black' };
            board[7][0] = board[7][7] = { type: 'rook', color: 'white' };
            board[0][1] = board[0][6] = { type: 'knight', color: 'black' };
            board[7][1] = board[7][6] = { type: 'knight', color: 'white' };
            board[0][2] = board[0][5] = { type: 'bishop', color: 'black' };
            board[7][2] = board[7][5] = { type: 'bishop', color: 'white' };
            board[0][3] = { type: 'queen', color: 'black' };
            board[7][3] = { type: 'queen', color: 'white' };
            board[0][4] = { type: 'king', color: 'black' };
            board[7][4] = { type: 'king', color: 'white' };
        }

        function getValidMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            const moves = [];
            const { type, color } = piece;
            const isValid = (r, c) => r >= 0 && r < 8 && c >= 0 && c < 8;
            const isEmptyOrEnemy = (r, c) => !board[r][c] || board[r][c].color !== color;

            if (type === 'pawn') {
                const dir = color === 'white' ? -1 : 1;
                const startRow = color === 'white' ? 6 : 1;
                if (isValid(row + dir, col) && !board[row + dir][col]) {
                    moves.push([row + dir, col]);
                    if (row === startRow && !board[row + 2 * dir][col]) {
                        moves.push([row + 2 * dir, col]);
                    }
                }
                for (let dc of [-1, 1]) {
                    const nr = row + dir, nc = col + dc;
                    if (isValid(nr, nc) && board[nr][nc] && board[nr][nc].color !== color) {
                        moves.push([nr, nc]);
                    }
                }
            }
            if (type === 'rook') {
                const dirs = [[0,1], [0,-1], [1,0], [-1,0]];
                for (let [dr, dc] of dirs) {
                    let r = row + dr, c = col + dc;
                    while (isValid(r, c)) {
                        if (!board[r][c]) {
                            moves.push([r, c]);
                        } else {
                            if (board[r][c].color !== color) moves.push([r, c]);
                            break;
                        }
                        r += dr; c += dc;
                    }
                }
            }
            if (type === 'knight') {
                const kmoves = [[2,1],[2,-1],[-2,1],[-2,-1],[1,2],[1,-2],[-1,2],[-1,-2]];
                for (let [dr, dc] of kmoves) {
                    const r = row + dr, c = col + dc;
                    if (isValid(r, c) && isEmptyOrEnemy(r, c)) {
                        moves.push([r, c]);
                    }
                }
            }
            if (type === 'bishop') {
                const dirs = [[1,1],[1,-1],[-1,1],[-1,-1]];
                for (let [dr, dc] of dirs) {
                    let r = row + dr, c = col + dc;
                    while (isValid(r, c)) {
                        if (!board[r][c]) {
                            moves.push([r, c]);
                        } else {
                            if (board[r][c].color !== color) moves.push([r, c]);
                            break;
                        }
                        r += dr; c += dc;
                    }
                }
            }
            if (type === 'queen') {
                const dirs = [[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
                for (let [dr, dc] of dirs) {
                    let r = row + dr, c = col + dc;
                    while (isValid(r, c)) {
                        if (!board[r][c]) {
                            moves.push([r, c]);
                        } else {
                            if (board[r][c].color !== color) moves.push([r, c]);
                            break;
                        }
                        r += dr; c += dc;
                    }
                }
            }
            if (type === 'king') {
                const dirs = [[0,1],[0,-1],[1,0],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]];
                for (let [dr, dc] of dirs) {
                    const r = row + dr, c = col + dc;
                    if (isValid(r, c) && isEmptyOrEnemy(r, c)) {
                        moves.push([r, c]);
                    }
                }
            }
            return moves;
        }

        function handleSquareClick(row, col) {
            if (gameOver) return;
            if (selectedSquare) {
                const [sr, sc] = selectedSquare;
                const isValidMove = validMoves.some(([r, c]) => r === row && c === col);
                if (isValidMove) {
                    const movingPiece = board[sr][sc];
                    const capturedPiece = board[row][col];
                    if (capturedPiece) {
                        capturedPieces[currentPlayer].push(capturedPiece);
                        if (capturedPiece.type === 'king') {
                            gameOver = true;
                            winner = currentPlayer;
                        }
                    }
                    board[row][col] = movingPiece;
                    board[sr][sc] = null;
                    if (movingPiece.type === 'pawn' && (row === 0 || row === 7)) {
                        board[row][col] = { type: 'queen', color: movingPiece.color };
                    }
                    currentPlayer = currentPlayer === 'white' ? 'black' : 'white';
                    selectedSquare = null;
                    validMoves = [];
                } else {
                    selectedSquare = null;
                    validMoves = [];
                }
            } else if (board[row][col] && board[row][col].color === currentPlayer) {
                selectedSquare = [row, col];
                validMoves = getValidMoves(row, col);
            }
            renderBoard();
            updateUI();
        }

        function renderBoard() {
            const boardEl = document.getElementById('chessBoard');
            boardEl.innerHTML = '';
            for (let row = 0; row < 8; row++) {
                const rowEl = document.createElement('div');
                rowEl.className = 'board-row';
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    square.className = 'square ' + ((row + col) % 2 === 0 ? 'light' : 'dark');
                    if (selectedSquare && selectedSquare[0] === row && selectedSquare[1] === col) {
                        square.classList.add('selected');
                    }
                    const isValidMove = validMoves.some(([r, c]) => r === row && c === col);
                    if (isValidMove) {
                        square.classList.add('valid-move');
                        if (board[row][col]) square.classList.add('has-piece');
                    }
                    const piece = board[row][col];
                    if (piece) {
                        const pieceEl = document.createElement('div');
                        pieceEl.className = 'piece ' + piece.color;
                        pieceEl.textContent = PIECE_SYMBOLS[piece.type];
                        square.appendChild(pieceEl);
                    } else if (isValidMove) {
                        const indicator = document.createElement('div');
                        indicator.className = 'valid-move-indicator';
                        square.appendChild(indicator);
                    }
                    square.onclick = () => handleSquareClick(row, col);
                    rowEl.appendChild(square);
                }
                boardEl.appendChild(rowEl);
            }
        }

        function updateUI() {
            const turnDisplay = document.getElementById('turnDisplay');
            turnDisplay.textContent = currentPlayer.charAt(0).toUpperCase() + currentPlayer.slice(1);
            turnDisplay.className = 'turn-display ' + currentPlayer;
            const gameOverEl = document.getElementById('gameOver');
            if (gameOver) {
                gameOverEl.classList.add('show');
                document.getElementById('winnerText').textContent = 
                    winner.charAt(0).toUpperCase() + winner.slice(1) + ' wins!';
            } else {
                gameOverEl.classList.remove('show');
            }
            const capturedWhiteEl = document.getElementById('capturedWhite');
            capturedWhiteEl.innerHTML = '';
            capturedPieces.white.forEach(piece => {
                const el = document.createElement('span');
                el.className = 'captured-piece';
                el.textContent = PIECE_SYMBOLS[piece.type];
                el.style.color = '#1e293b';
                capturedWhiteEl.appendChild(el);
            });
            const capturedBlackEl = document.getElementById('capturedBlack');
            capturedBlackEl.innerHTML = '';
            capturedPieces.black.forEach(piece => {
                const el = document.createElement('span');
                el.className = 'captured-piece';
                el.textContent = PIECE_SYMBOLS[piece.type];
                el.style.color = 'white';
                capturedBlackEl.appendChild(el);
            });
        }

        function resetGame() {
            selectedSquare = null;
            validMoves = [];
            currentPlayer = 'white';
            gameOver = false;
            winner = null;
            capturedPieces = { white: [], black: [] };
            initializeBoard();
            renderBoard();
            updateUI();
        }

        initializeBoard();
        renderBoard();
        updateUI();
    </script>
</body>
</html>
'''

@app.route('/')
def index():
    return render_template_string(HTML_TEMPLATE)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)