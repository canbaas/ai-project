# AI Chess Simulator

A fully functional **terminal chess game** in Python where you play **White** against a simple **AI (Black)**.

## ✨ Features
- Unicode chess pieces for a clean terminal board
- Legal move validation for all standard pieces (no castling/en-passant yet)
- Basic AI: evaluates material and prefers captures with a mini-lookahead
- Captured pieces and last 5 moves log
- Clear prompts and friendly errors

## 🛠️ Requirements
- Python 3.8+
- No external packages required

## ▶️ How to Run
```bash
# Clone the repo
git clone https://github.com/your-username/ai-chess-simulator.git
cd ai-chess-simulator

# Run
python3 main.py
```

## 🎮 Controls
- Enter moves in algebraic squares: `e2 e4` (from → to)
- Type `quit` to exit

## 📁 Project Structure
```
ai-chess-simulator/
├── main.py          # Game logic and entry point
├── README.md        # This file
├── LICENSE          # MIT License
└── requirements.txt # Empty (uses stdlib only)
```

## ⚠️ Known Limitations
- No check/checkmate detection; game ends when a king is captured or no moves remain
- No castling, en-passant, or pawn promotion
- AI is intentionally simple (good for demos and assignments)

## 🚀 Roadmap Ideas
- Add check/checkmate and stalemate logic
- Implement castling, en-passant, pawn promotion
- Replace AI with minimax + alpha-beta pruning
- Add PGN move notation
- Optional: GUI using `pygame` or `tkinter`

---

Made with ♟️ by you.
